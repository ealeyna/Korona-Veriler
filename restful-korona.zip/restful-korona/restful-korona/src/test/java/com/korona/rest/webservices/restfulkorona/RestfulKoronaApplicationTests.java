package com.korona.rest.webservices.restfulkorona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulKoronaApplicationTests {

	@Test
	void contextLoads() {
	}

}
